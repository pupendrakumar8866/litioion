<?php

if (!defined('ABSPATH')) die('No direct access.');
	
/**
 * Class to handle individual slideshow settings
 */
class MetaSlider_Settings {

}
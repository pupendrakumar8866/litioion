window.jQuery(function($) {
	/**
	 * Extra JS for the Nivo Bar theme
	 */

	$('.ms-theme-nivo-bar .slider-wrapper').each(function() {
		$(this).removeClass('theme-default');
	});
});
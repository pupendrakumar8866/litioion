<article class="nwsltr wrap">
<h1 class="lft">Subscribe & stay<br>
connected</h1>
<div class="fldWrp"><?php echo do_shortcode('[wpforms id="41" title="false" description="false"]'); ?></div><div class="clear"></div>
<div class="clear"></div>
</article>
<footer>
<div class="wrap">
<div class="cmpny">
<?php if ( is_active_sidebar( 'custom-header-widget' ) ) : ?>
    <ul id="sidebar">
        <?php dynamic_sidebar( 'custom-header-widget' ); ?>
    </ul>
<?php endif; ?>
</div>

<div class="ftrnv">
<?php wp_nav_menu(array(
  'theme_location' => 'footer_menu'
 )); ?>
</div>

<?php $catquery = new WP_Query( 'cat=8&posts_per_page=2' ); ?>
<ul class="blg">
<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
<li><aside class="lft"><?php the_post_thumbnail();?></aside>
<aside class="rgt"><?php the_title();?>
<h6><?php echo get_the_date(); ?></h6>
</aside><div class="clear"></div>
<?php endwhile;
    wp_reset_postdata();
?>
</li>
</ul>

<div class="clear"></div>
</div>
<div class="btmpnl"><div class="wrap"><p class="lft">Created by FOS</p> <p class="rgt">© Trio Tree Technologies, 2019. All rights reserved.</p><div class="clear"></div></div></div>
</footer>
<script>
    $(document).ready(function () {
        AfterPostBackHm();
        Sys.WebForms.PageRequestManager.getInstance().add_endRequest(AfterPostBackHm);
    });

    var AfterPostBackHm = (function () {
        $('.owl-carousel').owlCarousel({
            margin: 40,
            loop:true,
			dots: false,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 3
                }
                ,
                1200: {
                    items: 8
                }
            }
        })
		
		
		$('.owl-carousel2').owlCarousel({
            margin: 30,
            loop:true,
			dots: false,
			autoplay:false,
			autoplayTimeout:2000,
			autoplayHoverPause:true,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1020: {
                    items: 3
                }
                ,
                1200: {
                    items: 2
                }
            }
        })
		
		 });
</script>
<script>
var a = 0;
$(window).scroll(function() {

  var oTop = $('#counting').offset().top - window.innerHeight;
  if (a == 0 && $(window).scrollTop() > oTop) {
    $('.counter-value').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 2000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    a = 1;
  }

});
</script>
<?php wp_footer(); ?>
</body>
</html>
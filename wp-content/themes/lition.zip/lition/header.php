<!DOCTYPE>
<html>
<head>
<title>Trio Tree</title>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />	
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
<!--[if IE]> <script src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="css/ie.css" /><![endif]-->
<!--[if lte IE 7]> <script src="js/IE8.js" type="text/javascript"></script><![endif]-->
<!--[if lt IE 7]> <script src="js/IE7.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="css/ie6.css" /> 
<style> ul, li, a, img, div, span, dd, dl, dt {behavior: url("assets/iepngfix.htc")} </style> <![endif]-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<?php wp_head(); ?>
</head>

<body>
<header class="wrap">
<a href="<?php echo get_option("siteurl"); ?>" class="logo"><img src="<?php bloginfo('template_url');?>/images/logo.png"></a>
<nav>

<?php wp_nav_menu(array(
  'theme_location' => 'primary'
 )); ?>
<div class="clear"></div>
</nav>
<div class="clear"></div>
</header>





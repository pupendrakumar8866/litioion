<?php
/**
 * Template Name: about-us
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<div class="clear"></div>
<div class="bnr"><?php echo do_shortcode('[metaslider id="90"]'); ?></div>

<article class="about ppl wrap">
<aside class="lft">
<h2>About us</h2>
<h3>Our vision is to revolutionize the quality and efficiency of<br />
everyday patient experiences with the convergence of healthcare
</h3>
<p>TrioTree Technologies is amongst the most successful and respected information technology companies in the Indian healthcare space. Our Implementation Methodology aspires to bring together the best people, process and technology to enable an effortless digital transition of the hospital. We stand for innovation, uncompromising quality and process excellence for end to end hospital management solutions.
</p>
</aside>

<aside class="rgt"><img src="<?php bloginfo('template_url');?>/images/abt-rht.png" alt="Why Join"></aside>
<div class="clear"></div>
</article>

<article class="prlx certfic">
<div class="wrap">
<h1 class="hd">Our Certifications</h1>
<p>At a Glance</p>
<ul>
<?php
          $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1; // setup pagination
       $the_query = new WP_Query( array(
        'post_type' => 'Certifications',
        'paged' => $paged,
        'orderby' =>'ID',
        'order' =>'asc',        
        'posts_per_page' => -1)
       );      
       while ( $the_query->have_posts() ) : $the_query->the_post();        
       ?>
       <li><?php echo the_post_thumbnail(); ?></li>
       <?php endwhile; ?>
</ul>
<div class="clear"></div></div>
</article>

<article class="about ppl wrap">
<aside class="lft">
<h2>Our Story</h2>
<h3>We aspire to streamline healthcare operations for a better<br /> patient experience in all our endeavours for medical</h3>
<p>Our doctors and engineers, being stalwarts of healthcare, sensed the need of healthcare digitization for efficient healthcare delivery and better patient experiences. TrioTree Technologies stemmed from this very need. TrioTree Technologies’ brilliant team of doctors and engineers use their rich experience, expertise and domain knowledge to consistently innovate and deliver unparalleled suite of products and services in the healthcare domain. Today, TrioTree Technologies has emerged as one of the leading providers of healthcare solutions in India, UK and Malaysia</p></aside>

<aside class="rgt"><img src="<?php bloginfo('template_url');?>/images/abt-rht2.png" alt="Why Join"></aside>
<div class="clear"></div>
</article>

<section class="clincs">
<div class="wrap">
<h1><span>FOR CLINICIANS</span>BY CLINICIANS</h1>
<p>Our topmost priority is our clients and their satisfaction with<br /> our products and services.</p>
<ul>
<li><aside class="imgpnl"><img src="<?php bloginfo('template_url');?>/images/abt-img2.png" /></aside><aside class="txtpnl"><h2>Decades of Experience In The Healthcare Domain</h2>
<p>We aspire to provide you with the best support in the industry to manage your processes and workflows effortlessly. Our inhouse lab technicians, doctors, nurses and pharmacists, being healthcare experts themselves, completely understand and relate to the everyday glitches that a healthcare provider might face while interacting with patients.</p>
<a href="#">Learn More</a>
</aside></li>
<li><aside class="imgpnl"><img src="<?php bloginfo('template_url');?>/images/abt-img3.png" /></aside><aside class="txtpnl"><h2>Drive High-Quality, Cost-eective<br /> & Patient-Centric Care
</h2>
<p>Our healthcare solutions are directed towards the best  satisfaction of the healthcare provider. We strive for client satisfaction, confidentiality, cost-effectiveness and financial results in the volatile healthcare space. Scale your operations to multiple locations/ centres hassle-free with our world-class products and services.</p>
<a href="#">Learn More</a>
</aside></li>
</ul><div class="clear"></div></div>
</section>

<section class="whyUs">
<div class="wrap">
<h1 class="hd">Why Choose Us?</h1>
<p>We promise trust, commitment & global standards in all our<br /> healthcare innovations</p>
<ul><li><span><img src="<?php bloginfo('template_url');?>/images/abut-icn1.jpg" /></span>
<h2>Expertise</h2>
<p>TrioTree Technologies has a brilliant team of doctors, nurses & engineers who have global experience in healthcare product designing & deployment.</p>
<a href="#">Learn more</a></li>
<li><span><img src="<?php bloginfo('template_url');?>/images/abut-icn2.jpg" /></span>
<h2>Expertise</h2>
<p>TrioTree Technologies has a brilliant team of doctors, nurses & engineers who have global experience in healthcare product designing & deployment.</p>
<a href="#">Learn more</a></li>
<li><span><img src="<?php bloginfo('template_url');?>/images/abut-icn3.jpg" /></span>
<h2>Expertise</h2>
<p>TrioTree Technologies has a brilliant team of doctors, nurses & engineers who have global experience in healthcare product designing & deployment.</p>
<a href="#">Learn more</a></li>
</ul><div class="clear"></div>
</div></section>

<article class="prlx mrt0">
Meet our healthcare experts who are pioneering technological innovation & revolutionizing
healthcare globally 
<div class="clear"></div>
</article>

<section class="tem">
<h1 class="hd">Our Experts</h1>
<div class="wrap">
<ul>
<?php
       $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1; // setup pagination
       $the_query = new WP_Query( array(
        'post_type' => 'Team',
        'paged' => $paged,
        'orderby' =>'ID',
        'order' =>'asc',        
        'posts_per_page' => -1)
       );  
	   while ( $the_query->have_posts() ) : $the_query->the_post();        
       ?>
<li>
<span><img src="<?php echo the_post_thumbnail_url(); ?>" /></span>
<h2><b><?php the_field('team-post'); ?></b> <?php echo get_the_title(); ?></h2>
<p><?php echo get_the_content(); ?></p>
</li>
<?php endwhile; ?>
</ul>
<div class="clear"></div>
</div>
</section>
<?php get_footer(); ?>

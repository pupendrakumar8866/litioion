<?php get_header();?>

<div class="bnr"><?php echo do_shortcode('[metaslider id="90"]'); ?></div>

<article class="about wrap">
<aside class="lft">
<h2>Exclusively<br>
an Healthcare IT Company</h2>
<h3>TrioTree Technologies was founded by a group of doctors &
engineers with decades of experience in the healthcare
domain.
</h3>
<p>TrioTree Technologies promises to deliver an unparalleled suite of products and services
for your healthcare organization. TrioTree Technologies’ brilliant team of doctors and
engineers use their rich experience, expertise and domain knowledge to consistently
innovate and deliver excellent products and services. Today, TrioTree Technologies has
emerged as one of the leading providers of healthcare solutions in India, UK and
Malaysia. We aspire to streamline healthcare operations for a better patient experience
in all our endeavours for medical advancement.
</p>
</aside>
<aside class="rgt"><img src="<?php bloginfo('template_url');?>/images/about-rgt.jpg" alt="About Image"></aside>
<div class="clear"></div>
</article>

<section class="Quote" data-aos="flip-left">
<div class="wrap">
<p>Looking for a First-Class Business Plan Consultant?</p>
<a href="#" class="btn">Get a Quote </a></div></section>

<article class="count">
<h1 class="hd">We are Trio Tree <span>Trio Tree in Numbers</span></h1>
<ul id="counting" class="wrap">
<li><h1 class="counter-value plus" data-count="<?php the_field('cont-no-digit-1st'); ?>">+</h1>
<p>Total 200+ Years of comulative<br> healthcare experience </p></li>

<li><h1 class="counter-value plus k" data-count="<?php the_field('cont-no-digit-2nd'); ?>">+</h1>
<p>10K + Doctors online using our EMR<br> at any point of time</p></li>

<li><h1 class="counter-value plus m" data-count="<?php the_field('cont-no-digit-3rd'); ?>">+</h1>
<p>3.5 Million Patient Records</p></li>

<li><h1 class="counter-value plus k" data-count="<?php the_field('cont-no-digit-4th'); ?>">+</h1>
<p>14k + Nurse online using our EMR at <br>any point of time</p></li>
</ul>
</article>

<article class="prdct wrap">
<aside class="lft"><h1 class="hd">Our Products</h1>
<h3>Transforming Healthcare Workflow though Effortless, Efficient & Quality Driven Product Innovation</h3>
<h4>An Enterprise Hospital<br>
Information System  <span>Custom/Individual module also available</span></h4>
<a href="products" class="btn out">Explore</a>
<a href="#" class="btn out">Book a Demo</a>
</aside>

<aside class="rgt"><img src="<?php bloginfo('template_url');?>/images/prdts-rgt.jpg"></aside>
<div class="clear"></div>
</article>

<article class="servc">
<h1 class="hd">Our Offerings
<span>Product & Services that enhance your healthcare practice.</span></h1>
<ul class="wrap">
<li><span></span>
<h2>Products</h2>
<p>HISTree, AmbulaTree, LISTree, EyeYtee<br> OncoTree, DentisTree, HL7Tree, KIDTree & more</p>
<div class="clicks"><a href="#" class="lft">Learn more</a><a href="#" class="rgt">Book a demo</a></div>
</li>

<li><span class="icn2"></span>
<h2>Services</h2>
<p>Custom development, IT Infrastructure
Consulting, Management Consulting and more
</p><div class="clicks"><a href="#" class="lft">Learn more</a><a href="#" class="rgt">Book a demo</a></div>
</li>

</ul><div class="clear"></div>
</article>

<article class="wnr wrap"><aside class="lft"><img src="<?php bloginfo('template_url');?>/images/winning-lft.jpg"></aside>
<aside class="rgt">
<h1 class="hd">Awards & Accolade</h1>
<h3>Redefining quality improvement in healthcare organizations
worldwide</h3>
<p>Indian Express Healthcare IT Award 2016 (EMR Adoption)</p>
<p>IMC Award (2017) – Patient porta</p>
<p>JCI & NABH Accredited Clientele</p>
<p>Top 100 Healthcare Leaders Award - IFAH 2019</p>
<p>An ISO 9001:2015 and ISO 27001:2013 Certified Company</p>
</aside>
<div class="clear"></div>
</article>

<article class="client wrap">
<h1>Our happy Clientele is our biggest award</h1>
<ul class="owl-carousel owl-theme slidtraks">
<?php
          $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1; // setup pagination
       $the_query = new WP_Query( array(
        'post_type' => 'Clients',
        'paged' => $paged,
        'orderby' =>'ID',
        'order' =>'asc',        
        'posts_per_page' => 6)
       );      
       while ( $the_query->have_posts() ) : $the_query->the_post();        
       ?>
<li class="owl-item imgwrap"><img src="<?php echo the_post_thumbnail_url(); ?>" alt="Image Title"></li>
<!--extra-->
<li class="owl-item imgwrap"><img src="<?php bloginfo('template_url');?>/images/client-lgo2.jpg"></li>
<li class="owl-item imgwrap"><img src="<?php bloginfo('template_url');?>/images/client-lgo3.jpg"></li>
<li class="owl-item imgwrap"><img src="<?php bloginfo('template_url');?>/images/client-lgo4.jpg"></li>
<li class="owl-item imgwrap"><img src="<?php bloginfo('template_url');?>/images/client-lgo1.jpg"></li>
<li class="owl-item imgwrap"><img src="<?php bloginfo('template_url');?>/images/client-lgo2.jpg"></li>
<li class="owl-item imgwrap"><img src="<?php bloginfo('template_url');?>/images/client-lgo3.jpg"></li>
<li class="owl-item imgwrap"><img src="<?php bloginfo('template_url');?>/images/client-lgo4.jpg"></li>
<!--extra-->
<?php endwhile; ?>
</ul>
</article>

<article class="bkdmo">
<div class="wrap">
<h1>Join hundreds of practices getting benefit from our products & services.</h1> <a href="#" class="btn">BOOK A DEMO</a>
<div class="clear"></div>
</div>
</article>

<article class="testimonial wrap">
<h1 class="hd">Customer Speak
<span>What Our Customers Are Saying . . .</span></h1>

<ul class="owl-carousel2 owl-theme slidtraks">
 <?php
          $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1; // setup pagination
       $the_query = new WP_Query( array(
        'post_type' => 'testimonials',
        'paged' => $paged,
        'orderby' =>'ID',
        'order' =>'asc',        
        'posts_per_page' => 9)
       );      
       while ( $the_query->have_posts() ) : $the_query->the_post();        
       ?>
<li class="owl-item imgwrap"><a href="#"><span><img src="<?php echo the_post_thumbnail_url(); ?>" alt="Image Title"></span>
<p><?php echo get_the_content(); ?></p>
<h2><?php echo get_the_title(); ?></h2>
</a></li>
<?php endwhile; ?>
</ul>
</article>

<article class="blog">
<div class="wrap">
<h1 class="lft">From our blog</h1><a href="#" class="btn">Read more</a>
<div class="clear"></div>
<?php $catquery = new WP_Query( 'cat=8&posts_per_page=2' ); ?>
<ul>
<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
<li><span><?php the_post_thumbnail();?></span>
<h2><?php the_title();?></h2>
<div class="clicks"><a href="<?php the_permalink();?>">read more</a></div>
<?php endwhile;
    wp_reset_postdata();
?>
</li>
</ul><div class="clear"></div></div>
</article>
<?php get_footer();?>